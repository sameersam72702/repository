/*
SQLyog Community Edition- MySQL GUI v6.07
Host - 5.0.67-community-nt : Database - blood
*********************************************************************
Server version : 5.0.67-community-nt
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `blood`;

USE `blood`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `admintable` */

DROP TABLE IF EXISTS `admintable`;

CREATE TABLE `admintable` (
  `username` varchar(30) default NULL,
  `pass` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admintable` */

insert  into `admintable`(`username`,`pass`) values ('admin','admin');

/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `name` varchar(30) default NULL,
  `address` varchar(100) default NULL,
  `phno` varchar(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `bank` */

insert  into `bank`(`name`,`address`,`phno`) values ('spandana blood bank','guntur','99999999');

/*Table structure for table `registration` */

DROP TABLE IF EXISTS `registration`;

CREATE TABLE `registration` (
  `fname` varchar(30) default NULL,
  `lname` varchar(30) default NULL,
  `dob` date default NULL,
  `hno` varchar(10) default NULL,
  `street` varchar(30) default NULL,
  `city` varchar(30) default NULL,
  `state` varchar(30) default NULL,
  `country` varchar(30) default NULL,
  `pincode` varchar(30) default NULL,
  `contactno` varchar(30) default NULL,
  `email` varchar(40) default NULL,
  `login` varchar(30) default NULL,
  `pass` varchar(30) default NULL,
  `bloodgr` varchar(10) default NULL,
  `role` varchar(10) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `registration` */

insert  into `registration`(`fname`,`lname`,`dob`,`hno`,`street`,`city`,`state`,`country`,`pincode`,`contactno`,`email`,`login`,`pass`,`bloodgr`,`role`) values ('syed','rafiullah','2000-05-03','1','east street','Hyderabad','Andhra pradesh','India','522236','+919642520152','syedrafiullah02@gmail.com','aaa','aaa','a-','user');

/*Table structure for table `request` */

DROP TABLE IF EXISTS `request`;

CREATE TABLE `request` (
  `uname` varchar(30) default NULL,
  `donar` varchar(30) default NULL,
  `message` varchar(100) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `request` */

insert  into `request`(`uname`,`donar`,`message`) values ('syed','raju','plz we need blood');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
